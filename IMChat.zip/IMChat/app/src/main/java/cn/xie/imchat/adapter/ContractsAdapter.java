package cn.xie.imchat.adapter;

import android.content.Context;

import java.util.List;

import cn.xie.imchat.domain.ChatUser;

/**
 * @author xiejinbo
 * @date 2019/9/20 0020 13:40
 */
public class ContractsAdapter {
    private Context mContext;
    private List<ChatUser> chatUserList;

    public ContractsAdapter(Context context, List<ChatUser> chatUsers){
        this.mContext = context;
        this.chatUserList = chatUsers;
    }
}
