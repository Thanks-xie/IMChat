package cn.xie.imchat.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import cn.xie.imchat.domain.ChatUser;

/**
 * @author xiejinbo
 * @date 2019/9/20 0020 11:17
 */
public class DBManager {
    private DBHelper dbHelper;
    private SQLiteDatabase database;

    public DBManager(Context context){
        dbHelper = new DBHelper(context);
        database = dbHelper.getWritableDatabase();
    }

    /**
     * 添加好友到数据库
     * @param chatUsers
     * @return
     */
    public boolean addChatUserData(List<ChatUser> chatUsers){
        try {
            database.beginTransaction();
            for (ChatUser chatUser: chatUsers){
                ChatUser chatUser1 = queryChatUserByName(chatUser.getName());
                if (chatUser1 != null){
                    updateChatUserData(chatUser);
                    continue;
                }
                final String sql = "INSERT INTO user VALUES(NULL,?,?)";
                Object[] objects = new Object[]{chatUser.getName(),chatUser.getJid()};
                database.execSQL(sql,objects);
            }
            database.setTransactionSuccessful();
        } catch (Exception e) {
            return false;
        } finally {
            if (database.inTransaction()) {
                database.endTransaction();
            }
        }
        return true;
    }

    /**
     * 更新表中数据
     * @param chatUser
     * @return
     */
    public boolean updateChatUserData(ChatUser chatUser){
        try {
            ContentValues values = new ContentValues();
            values.put("jid", chatUser.getJid());
            database.beginTransaction();
            database.update("user", values, "name=?", new String[]{chatUser.getName()});
            database.setTransactionSuccessful();
        } catch (Exception e) {
            return false;
        } finally {
            if (database.inTransaction()) {
                database.endTransaction();
            }
        }
        return true;
    }

    /**
     * 根据用户名查询用户
     * @param userName
     * @return
     */
    public ChatUser queryChatUserByName(String userName){
        ChatUser chatUser = new ChatUser();
        try {
            String sql = "select * from user where name=? ";
            Cursor cursor = database.rawQuery(sql, new String[]{userName});
            while (cursor.moveToNext()) {
                chatUser.setName(userName);
                chatUser.setJid(cursor.getString(cursor.getColumnIndex("jid")));
            }
            cursor.close();
        } catch (Exception e) {
            Log.e("queryChatUserByName",e.toString());
        }
        return chatUser;
    }
    /**
     * 查询所有好友
     * @return
     */
    public List<ChatUser> queryAllChatUser(){
        List<ChatUser> chatUsers = new ArrayList<>();
        ChatUser chatUser = new ChatUser();
        try {
            String sql = "select * from user ";
            Cursor cursor = database.rawQuery(sql,null);
            while (cursor.moveToNext()) {
                chatUser.setName(cursor.getString(cursor.getColumnIndex("name")));
                chatUser.setJid(cursor.getString(cursor.getColumnIndex("jid")));
                chatUsers.add(chatUser);
            }
            cursor.close();
        } catch (Exception e) {
            Log.e("queryAllChatUser",e.toString());
        }
        return chatUsers;
    }

}
