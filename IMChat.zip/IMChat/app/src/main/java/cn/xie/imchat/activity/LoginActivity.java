package cn.xie.imchat.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import cn.xie.imchat.R;
import cn.xie.imchat.config.XmppConnection;
import cn.xie.imchat.utils.Util;

public class LoginActivity extends BaseActivity {
    private TextView inputName,inputPassword;
    private Button loginBtn;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        context = this;
        initView();
    }

    private void initView() {
        inputName = findViewById(R.id.name_text);
        inputPassword = findViewById(R.id.password_text);
        loginBtn = findViewById(R.id.login);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = inputName.getText().toString();
                String userPassWord = inputPassword.getText().toString();
                boolean isLogin = XmppConnection.getInstance().login(userName,userPassWord);
                if (isLogin){
                    Util.saveLoginStatic(context,userName,userPassWord);
                    Util.startChatService(context);
                    Intent intent = new Intent(context,MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}
