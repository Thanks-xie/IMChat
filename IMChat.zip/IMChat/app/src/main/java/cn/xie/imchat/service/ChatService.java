package cn.xie.imchat.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;

import org.jivesoftware.smack.roster.RosterEntry;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import cn.xie.imchat.config.XmppConnection;
import cn.xie.imchat.domain.ChatUser;
import cn.xie.imchat.domain.LoginUser;
import cn.xie.imchat.utils.DBManager;
import cn.xie.imchat.utils.Util;

public class ChatService extends Service {
    private Context context;
    private DBManager dbManager;
    public ChatService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        context = this;
        dbManager = new DBManager(context);
        judgeLoginXMPP();
        createThreadPool();
        return START_STICKY;
    }

    /**
     * 启动线程池
     */
    private void createThreadPool(){
        ExecutorService pool = Executors.newFixedThreadPool(1);
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                handlerInitAllFriends.sendEmptyMessage(1);
            }
        });
        pool.execute(thread1);
        pool.shutdown();

    }

    /**
     * 判断是否连接并登录了XMpp
     */
    private void judgeLoginXMPP() {
        if (!XmppConnection.getInstance().checkConnection()){
            XmppConnection.getInstance().getConnection();
        }
        if (!XmppConnection.getInstance().checkAuthenticated()){
            LoginUser user = new LoginUser();
            user = Util.getLoginInfo(context);
            XmppConnection.getInstance().login(user.getUserName(),user.getPassword());
        }
    }

    /**
     * 加载所有好友
     */
    private Handler handlerInitAllFriends = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            List<ChatUser> chatUsers = dbManager.queryAllChatUser();
            if (chatUsers==null||chatUsers.size()==0){
                getAllFriends();
            }
        }
    };

    /**
     * 加载所有好友
     */
    private void getAllFriends() {
        List<RosterEntry> entryList = XmppConnection.getInstance().getAllEntries();
        if (entryList!=null){
            List<ChatUser> chatUsers = new ArrayList<>();
            for (RosterEntry rosterEntry:entryList){
                if ("both".equals(rosterEntry.getType().toString())){
                    ChatUser chatUser = new ChatUser();
                    chatUser.setName(rosterEntry.getName());
                    chatUser.setJid(rosterEntry.getJid().toString());
                    chatUsers.add(chatUser);
                }
            }
            if (chatUsers!=null&&chatUsers.size()>0){
                dbManager.addChatUserData(chatUsers);
            }
        }

    }

}
