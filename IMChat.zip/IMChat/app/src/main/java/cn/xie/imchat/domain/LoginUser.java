package cn.xie.imchat.domain;

/**
 * @author xiejinbo
 * @date 2019/9/20 0020 10:05
 */
public class LoginUser {
    private String userName;
    private String password;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
