package cn.xie.imchat.domain;

/**
 * @author xiejinbo
 * @date 2019/9/20 0020 11:19
 */
public class ChatUser {
    private String name;
    private String jid;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJid() {
        return jid;
    }

    public void setJid(String jid) {
        this.jid = jid;
    }
}
