package cn.xie.imchat.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.TextUtils;

import java.util.ArrayList;

import cn.xie.imchat.domain.LoginUser;
import cn.xie.imchat.service.ChatService;

import static android.content.Context.MODE_PRIVATE;

/**
 * @author xiejinbo
 * @date 2019/9/19 0019 13:27
 */
public class Util {

    /**
     * 保存登录状态
     * @param context
     * @param userName
     */
    public static void saveLoginStatic(Context context,String userName,String password){
        SharedPreferences sharedPreferences =context.getSharedPreferences("login_data",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("userName",userName);
        editor.putString("password",password);
        editor.apply();
    }

    /**
     * 获取登录状态
     * @param context
     * @return
     */
    public static boolean getLoginStatic(Context context){
        SharedPreferences sharedPreferences = context.getSharedPreferences("login_data", MODE_PRIVATE);
        String userName = sharedPreferences.getString("userName","");
        if (TextUtils.isEmpty(userName)){
            return false;
        }else {
            return true;
        }
    }

    /**
     * 获取登录用户信息
     * @param context
     * @return
     */
    public static LoginUser getLoginInfo(Context context){
        SharedPreferences sharedPreferences = context.getSharedPreferences("login_data",MODE_PRIVATE);
        String userName = sharedPreferences.getString("userName","");
        String password = sharedPreferences.getString("password","");
        LoginUser user = new LoginUser();
        user.setUserName(userName);
        user.setPassword(password);
        return user;
    }

    /**
     * 启动 ChatService服务
     * @param context
     */
    public static void startChatService(Context context){
        if (!isServiceRunning(context, "cn.xie.imchat.service.ChatService")) {
            Intent intent = new Intent(context, ChatService.class);
            context.startService(intent);
        }
    }

    /**
     * 判断服务是否已经启动
     * @param context
     * @param ServiceName
     * @return
     */
    public static boolean isServiceRunning(Context context, String ServiceName) {
        if (("").equals(ServiceName) || ServiceName == null)
        {
            return false;
        }
        ActivityManager myManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ArrayList<ActivityManager.RunningServiceInfo> runningService = (ArrayList<ActivityManager.RunningServiceInfo>) myManager.getRunningServices(30);
        for (int i = 0; i < runningService.size(); i++) {
            if (runningService.get(i).service.getClassName().toString().equals(ServiceName)) {
                return true;
            }
        }
        return false;
    }


}
