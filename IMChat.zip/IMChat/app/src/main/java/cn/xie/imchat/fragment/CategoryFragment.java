package cn.xie.imchat.fragment;


import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.alibaba.fastjson.JSON;

import java.util.ArrayList;
import java.util.List;

import androidx.fragment.app.Fragment;
import cn.xie.imchat.R;
import cn.xie.imchat.domain.ChatUser;
import cn.xie.imchat.utils.DBManager;

/**
 * A simple {@link Fragment} subclass.
 */
public class CategoryFragment extends Fragment {
    private DBManager dbManager;
    private Activity context;
    private List<ChatUser> chatUsers;
    private ListView listView;


    public CategoryFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_category, container, false);
        listView = view.findViewById(R.id.listView);
        context = getActivity();
        dbManager = new DBManager(context);
        initData();
        return view;
    }

    /**
     * 获取所有好友
     */
    private void initData() {
        chatUsers = new ArrayList<>();
        chatUsers = dbManager.queryAllChatUser();
        Log.e("xjbo","chatUsers 11: "+ JSON.toJSONString(chatUsers));

    }

}
